class test implements testable
{
    public void display()
    {
        System.out.println("Implementation of interface.");
    }
}