abstract class abstest implements testable
{
    public void display ()
    {
        System.out.println("Abstarct class implementation.");
    }
}