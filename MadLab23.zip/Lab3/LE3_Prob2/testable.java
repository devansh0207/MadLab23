interface testable
{
    void display();
}