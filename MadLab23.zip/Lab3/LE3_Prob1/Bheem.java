class Bheem extends Pandav
{
    public void kind()
    {
        System.out.println("Bheem was a little less kind.");
    }
    
    public Bheem()
    {
        this.kind();
    }
}