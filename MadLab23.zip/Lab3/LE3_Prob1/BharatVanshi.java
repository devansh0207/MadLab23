abstract class BharatVanshi
{
    public int fight;
    public void fight()
    {
        System.out.println("Bharatvanshis were fighters.");
    }
}