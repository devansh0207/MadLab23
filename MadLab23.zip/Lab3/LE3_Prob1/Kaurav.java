class Kaurav extends BharatVanshi
{
    public void fight()
    {
        System.out.print("Kauravs were bharatvanshi. ");
        super.fight();
    }
    
    public void disObey()
    {
        System.out.println("Kaurvs were disobedient.");
    }
    
    public void cruel()
    {
        System.out.println("Kauravs were cruel.");
    }
    
    public Kaurav()
    {
        this.fight();
    }
}