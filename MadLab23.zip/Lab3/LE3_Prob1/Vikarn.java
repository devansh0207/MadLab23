class Vikarn extends Kaurav
{
    public void kind()
    {
        System.out.println("Vikarn was kind");
    }
    
    public void obey()
    {
        System.out.println("Vikarn was obedient.");
    }
    
    public Vikarn()
    {
        this.kind();
        this.obey();
    }
}