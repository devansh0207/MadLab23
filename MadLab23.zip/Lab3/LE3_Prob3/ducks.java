abstract class ducks
{
    void swim()
    {
        System.out.println("Capable of swimming.");
    }
    
    ducks()
    {
        swim();
    }
}