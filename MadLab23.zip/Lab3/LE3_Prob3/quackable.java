interface quackable
{
    void sound();
}