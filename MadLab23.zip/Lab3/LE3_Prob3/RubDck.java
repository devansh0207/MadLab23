class RubDck extends ducks implements quackable
{
    public void sound()
    {
        System.out.println("Squeaks");
    }
    
    RubDck()
    {
        sound();
    }
}