class WoodDck extends ducks
{
    
}