interface flyable
{
    void fly();
}