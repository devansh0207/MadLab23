public class mother
{
    public void show()
    {
        System.out.println("This is Mother.");
    }
}