class mother
{
    public void show()
    {
        System.out.print("This is Mother");
    }
}