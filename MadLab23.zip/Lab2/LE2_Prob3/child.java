class child extends mother
{
    public void show()
    {
        System.out.println("This is Child");
    }
}