class two extends one
{
    two(int x)
    {
        super(x);
    }
}