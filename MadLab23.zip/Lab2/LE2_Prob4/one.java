class one
{
    one(int x)
    {
        System.out.printf("One's Parameter = %d",x);
    }
}