class second extends first
{
    public void diss()
    {
        System.out.println("This is Child");
    }
}