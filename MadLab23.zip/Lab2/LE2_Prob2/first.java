class first
{
    public void diss()
    {
        System.out.println("This is Mother");
    }
}